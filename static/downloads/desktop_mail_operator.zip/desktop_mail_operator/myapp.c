#include <stdio.h>

int main() {
    printf("Hello, Universal Binary!\n");
    return 0;
}
